SpeedPingur 1.0.0 - Portable

QUICK START
-----------
1. Extract folder
2. Run SpeedPingur.exe

REQUIREMENTS
------------
Windows 10/11 (64-bit)
Internet connection

SUPPORT
-------
https://github.com/TheStoicSpirit/SpeedPingur
